CREATE VIEW V_TERMINALNOTRANS AS SELECT SHH AS MERCHANTNO,
            MAX (SHMC) AS MERCHANTNAME,
            ZDH AS TERMINALNO,
            SUM (DECODE (t.JYNY, '201710', t.jybs, 0)),
            SUM (DECODE (t.JYNY, '201710', t.jyje, 0)),
            SUM (DECODE (t.JYNY, '201711', t.jybs, 0)),
            SUM (DECODE (t.JYNY, '201711', t.jyje, 0)),
            SUM (DECODE (t.JYNY, '201712', t.jybs, 0)),
            SUM (DECODE (t.JYNY, '201712', t.jyje, 0))
       FROM ys_transmounth t
      WHERE JYNY BETWEEN 201710 AND 201712
   GROUP BY SHH, ZDH
/
