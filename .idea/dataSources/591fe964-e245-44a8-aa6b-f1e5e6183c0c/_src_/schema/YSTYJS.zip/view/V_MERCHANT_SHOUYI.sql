CREATE VIEW V_MERCHANT_SHOUYI AS SELECT JYNY AS SETTLEDATE,
            SHH AS MERCHANTNO,
            SHMC AS MERCHANTNAME,
            ZDH AS TERMINALNO,
            SUM (JYBS) AS TRANSCOUNT,
            SUM (JYJE) AS TRANSAMOUNT,
            SUM (JYSXF) AS TRANSFEE,
            SUM (DZSXF) AS DIANZI,
            SUM (
               CASE
                  WHEN DZSXF IS NOT NULL THEN JYJE / 10000 * 2
                  WHEN DZSXF IS NULL THEN 0
               END)
               AS DIANZICB,
            SUM (TDF) AS TRANSTD,
            SUM (JYSXF - TDF) AS FEEINCOME,
            SUM (
               CASE
                  WHEN DZSXF IS NOT NULL THEN DZSXF - JYJE / 10000 * 2
                  WHEN DZSXF IS NULL THEN 0
               END)
               AS DIANZIINCOME,
            SUM (
                 (JYSXF - TDF)
               + (CASE
                     WHEN DZSXF IS NOT NULL THEN DZSXF + 0
                     WHEN DZSXF IS NULL THEN 0
                  END))
               AS TOTALINCOME
       FROM ys_transmounth
      WHERE     ZDH NOT IN ('00000000', '00000001', '01080209')
            AND jgh != '1121000005'                                       --瀚迪
            AND DLSBH NOT IN ('801121099990004',                     --理财代理商编号
                              '801146088887742',           --廊坊市四友商贸有限公司（大POS）
                              '801146088888898',       --廊坊和硕商务信息咨询服务有限公司（POS）
                              '801127088883049',               --邯郸市银华电子科技有限公司
                              '801124088883232',          --唐山邻家电子商务有限公司（大POS）
                              '801146088883230',     --廊坊市中龙德宝商务信息咨询有限公司（大POS）
                              '801134088882575',          --河北帅众网络科技有限公司（大pos）
                              '801146199992160',                        --河北代理
                              '801121099991622',                        --河北测试
                              '801121099997567',                        --河北代理
                              '801121088884408'                 --河北致岱科技有限公司扫码
                                               )
   GROUP BY SHH,
            SHMC,
            ZDH,
            JYNY
/
