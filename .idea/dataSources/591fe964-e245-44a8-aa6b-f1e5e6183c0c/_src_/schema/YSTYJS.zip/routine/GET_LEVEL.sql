CREATE FUNCTION get_level(  zx    IN  VARCHAR2,  zs    IN  VARCHAR2)
RETURN varchar2
IS
  erzi    VARCHAR2(25);

BEGIN
select d.AGENTNUMBER into erzi  from (select ONAGENTNUMBER, AGENTNUMBER, AGENTGRADE lv
  from CREDITCARD_AGENTRELATION start with AGENTNUMBER=zs connect by prior ONAGENTNUMBER=AGENTNUMBER) d
  where ONAGENTNUMBER=zx;
  RETURN(erzi);
END get_level;
/
