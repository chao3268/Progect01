CREATE procedure sql_test(bankname IN VARCHAR2 ,local  IN VARCHAR2 ,datenow  IN VARCHAR2,out_return out sys_refcursor) is
begin
  open out_return for select
    rownum as
    passagefee,acono,merchantno,merchantname,terminalno,transdate,transtime,transcardno,transcardname,
    receiptcardno,receiptcardname,transamount,manualservicecharge,manualadvancefee,
    sum(manualservicecharge+manualadvancefee) over (partition by acono) as
    ordernumber,localmarket
    from Excledata where merchantname like bankname and
    localmarket=local and
    substr(transdate,0,6)=datenow order by passagefee;
end;
/
