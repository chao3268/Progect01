CREATE FUNCTION getChildList (rootId VARCHAR(100)) -- rootId为要查询的节点
 RETURNS VARCHAR(1000)
 BEGIN
 DECLARE pTemp VARCHAR(1000); -- 定义两个临时变量
 DECLARE cTemp VARCHAR(1000); -- 定义两个临时变量
 SET pTemp = '';
 SET cTemp = rootId;
 WHILE cTemp is not null DO
 if (pTemp = '') then
 SET pTemp = cTemp;
 elseif(pTemp <> '') then
 SET pTemp = concat(pTemp,',',cTemp); -- 所有节点连接成字符串
 end if;
 SELECT group_concat(id) INTO cTemp FROM treeList  WHERE FIND_IN_SET(pId,cTemp)>0;
 END WHILE;
 RETURN pTemp;
 END;
/
