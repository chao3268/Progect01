CREATE FUNCTION        fun_showCardNo(p_cardNo IN VARCHAR2) RETURN VARCHAR2 IS
  resultStr VARCHAR2(48);
  LcardNo varchar2(12);
  RcardNo varchar2(8);
  CcardNo varchar2(40);
BEGIN
  if(length(p_cardNo)>9) then
    LcardNo := substr(p_cardNo,0,6);
    RcardNo := substr(p_cardNo,-4);
    /*for i in 1..length(p_cardNo)-10 loop
      CcardNo := CcardNo ||'*';
    end loop;*/
    CcardNo := '****';
    resultStr := LcardNo || CcardNo || RcardNo;
  else
    resultStr := '';
  end if;
  RETURN(resultStr);
END fun_showCardNo;
/
